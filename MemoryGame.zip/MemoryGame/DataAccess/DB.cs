﻿using Model;
using System.Data.SqlClient;
namespace DataAccess;

public class DB : IHighscores
{
    public string ConnectionString { get; set; }
    public DB(string connectionString)
    {
        if (!IsConnectionStringValid(connectionString))
        {
            throw new InvalidConnectionStringException();
        }
        ConnectionString = connectionString;
    }

    private bool IsConnectionStringValid(string connectionString)
    {
        return true;
    }

    public void InsertHighscore(Highscores highscores)
    {
        string sql = "INSERT INTO Highscores (Highscore, Name) VALUES (@Highscore, @Name);"; //query voor het inserten
        int recordsAffected = 0;

        using (var connection = new SqlConnection(ConnectionString)) {
            using (var command = new SqlCommand(sql, connection))
            {
                command.Parameters.AddWithValue("Highscore", highscores.Highscore);
                command.Parameters.AddWithValue("Name", highscores.Name);
           
                connection.Open();
                recordsAffected = command.ExecuteNonQuery();
                connection.Close();
            }                
        }
    }
    
    public List<Highscores> SelectHighscores()
    {
        var Highscores = new List<Highscores>();
        string sql = "SELECT playerID, Highscore, Name FROM Highscores;"; //query voor het selecten

        using (var connection = new SqlConnection(ConnectionString))
        {
             using (var command = new SqlCommand(sql, connection))
             {
                 connection.Open();
                 var reader = command.ExecuteReader();
                  
                 while (reader.Read()) //het uitlezen van de highscore klasse
                 {                         
                     var item = new Highscores();
                     item.PlayerId = reader.GetInt32(0);
                     item.Highscore = reader.GetInt32(1);
                     item.Name = reader.GetString(2);
                     
                     Highscores.Add(item);
                 }
                 connection.Close();
             }
             return Highscores;
        }
    }
}