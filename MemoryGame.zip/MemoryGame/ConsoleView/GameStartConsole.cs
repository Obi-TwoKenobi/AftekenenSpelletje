﻿using Model;
using System;
using System.Diagnostics;
using System.Timers;
using DataAccess;
using Timer = System.Timers.Timer;

namespace ConsoleView;

public class GameStartConsole
{
    private DB DataAccess = new DB("Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=Memory;Integrated Security=True;");
    private Stopwatch Stopwatch;

    public GameStartConsole()
    {
        Stopwatch = new Stopwatch();
    }

    public void Start(Game game)
    {
        var query = DataAccess.SelectHighscores().OrderByDescending(h => h.Highscore).Take(10);
        foreach (var highscore in query)
        {
            Console.WriteLine($"Speler: {highscore.Name} heeft een score van {highscore.Highscore}");
        }
        Console.WriteLine("\nWelkom bij dit Memory spel. Het is de bedoeling om alle paren te vinden wanneer dat is gelukt heb je gewonnen!\nOm te spelen moet je steeds 2 coördinaten opgeven. Dat doe je op deze manier 1 enter 2\nVeel plezier bij het spelen!!");
        Console.WriteLine("Vul alsublieft eerst uw naam in");
        String name = Console.ReadLine();
        Stopwatch.Start();
        while (!game.Solved)
        {
            Console.WriteLine("Wat zijn uw volgende zetten?");
            int input1 = Convert.ToInt32(Console.ReadLine());
            int input2 = Convert.ToInt32(Console.ReadLine());
            
            var card1 = game.GetCardForPlace(game.Kaarten, input1);
            var card2 =game.GetCardForPlace(game.Kaarten, input2);
            
            game.CheckPair(card1, card2, game);
            game.attempts++;
            
            Console.Clear();
            game.PrintBoard(game.CardsList);
            game.CardFlipDownside(card1, card2);
            
        }

        //wanneer je alle pairs hebt gevonden 
        if (game.Solved)
        {
            Stopwatch.Stop();
            double elapsedSeconds = Stopwatch.Elapsed.TotalSeconds;
            Highscores playerHighscore = new Highscores();
            playerHighscore.Highscore = game.CalculateHighscore(elapsedSeconds, game.attempts, game.CardsList.Count );
            playerHighscore.Name = name;
            Console.WriteLine($"Gefeliciteert u heeft gewonnen. Uw score is {playerHighscore.Highscore}");
            DataAccess.InsertHighscore(playerHighscore);
        }
    }
}