﻿using ConsoleView;
using Model;

Game game = new Game();
GameStartConsole gameStartConsole = new GameStartConsole(); //nieuwe console maken
List<Cards> Kaartenlijst = game.MakeCards(2); //aantal kaarten aangeven
game.ShuffleBoard(Kaartenlijst); //kaartenlijst husselen
game.PrintBoard(Kaartenlijst); //speelbord printen
gameStartConsole.Start(game); //game starten


