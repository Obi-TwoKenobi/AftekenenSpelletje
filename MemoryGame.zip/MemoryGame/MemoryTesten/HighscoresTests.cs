﻿namespace MemoryTesten;
using Model;
public class HighscoresTests
{
    [Test]
    public void TestHighscoreProperty()
    {
        // Arrange
        int expectedHighscore = 1000;
        Highscores highscore = new Highscores();

        // Act
        highscore.Highscore = expectedHighscore;
        int actualHighscore = highscore.Highscore;

        // Assert
        Assert.AreEqual(expectedHighscore, actualHighscore);
    }

    [Test]
    public void TestPlayerIdProperty()
    {
        // Arrange
        int expectedPlayerId = 42;
        Highscores highscore = new Highscores();

        // Act
        highscore.PlayerId = expectedPlayerId;
        int actualPlayerId = highscore.PlayerId;

        // Assert
        Assert.AreEqual(expectedPlayerId, actualPlayerId);
    }

    [Test]
    public void TestNameProperty()
    {
        // Arrange
        string expectedName = "John Doe";
        Highscores highscore = new Highscores();

        // Act
        highscore.Name = expectedName;
        string actualName = highscore.Name;

        // Assert
        Assert.AreEqual(expectedName, actualName);
    }
    
}