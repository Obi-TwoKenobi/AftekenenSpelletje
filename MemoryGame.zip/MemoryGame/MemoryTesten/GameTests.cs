namespace MemoryTesten;
using System;
using NUnit.Framework;
using Model;
[TestFixture]
public class GameTests
{
    private List<Cards> placeWithCard;

    [SetUp]
    public void Setup()
    {
        // Initialize or set up the test data
        placeWithCard = new List<Cards>
        {
            new Cards { Id = 1, plaats = 1},
            new Cards { Id = 2, plaats = 2},
            new Cards { Id = 3, plaats = 3},
        };
    }
    
    [Test]
    public void CalculateHighscore_ValidInput_ReturnsHighscore()
    {
        // Arrange
        Game game = new Game();

        // Act
        int highscore = game.CalculateHighscore(20, 5, 16); // 16 cards, 60 seconds, 10 attempts

        // Assert
        Assert.AreEqual(2560, highscore); // Expected highscore based on the formula
    }

    [Test]
    public void CalculateHighscore_ZeroSeconds_ReturnsZero()
    {
        // Arrange
        Game game = new Game();

        // Act
        int highscore = game.CalculateHighscore(0, 5, 12); // 12 cards, 0 seconds, 5 attempts

        // Assert
        Assert.AreEqual(0, highscore);
    }

    [Test]
    public void CalculateHighscore_ZeroAttempts_ReturnsZero()
    {
        // Arrange
        Game game = new Game();

        // Act
        int highscore = game.CalculateHighscore(30, 0, 8); // 8 cards, 30 seconds, 0 attempts

        // Assert
        Assert.AreEqual(0, highscore);
    }

    
    [Test]
    public void CheckPair_WhenMatchingPair_ShouldReturnTrue()
    {
        // Arrange
        Game game = new Game();
        Cards cardsA = new Cards(1);
        Cards cardsB = new Cards(1);
        

        // Act
        game.CheckPair(cardsA, cardsB, game);

        // Assert
        Assert.That(cardsA.IsFound, Is.True);
        Assert.That(game.Found, Is.EqualTo(1));
        Assert.That(game.Solved, Is.False);
    }

    [Test]
    public void CheckPair_WhenNonMatchingPair_ShouldReturnFalse()
    {
        // Arrange
        Game game = new Game();
        Cards cardsA = new Cards(1);
        Cards cardsB = new Cards(2);

        // Act
        game.CheckPair(cardsA, cardsB, game);

        // Assert
        Assert.That(cardsA.IsFound, Is.False);
        Assert.That(game.Found, Is.EqualTo(0));
        Assert.That(game.Solved, Is.False);
    }

    [Test]
    public void CheckPair_WhenAllPairsFound_ShouldSetSolvedToTrue()
    {
        // Arrange
        Game game = new Game();
        game.aantalKaarten = 1;
        Cards cardsA = new Cards(1);
        Cards cardsB = new Cards(1);
        

        // Act
        game.CheckPair(cardsA, cardsB, game); 

        // Assert
        Assert.That(game.Solved, Is.True);
    }
    
    [Test]
    public void CardFlipDownside_NonFoundCards_ShouldResetSelected()
    {
        // Arrange
        Game game = new Game();
        Cards a = new Cards { IsFound = false, Selected = true };
        Cards b = new Cards { IsFound = false, Selected = true };

        // Act
        game.CardFlipDownside(a, b);

        // Assert
        Assert.That(a.Selected, Is.False);
        Assert.That(b.Selected, Is.False);
    }

    [Test]
    public void CardFlipDownside_FoundCard_ShouldResetSelectedWhenFound()
    {
        // Arrange
        Game game = new Game();
        Cards a = new Cards { IsFound = true, Selected = true };
        Cards b = new Cards { IsFound = false, Selected = true };

        // Act
        game.CardFlipDownside(a, b);

        // Assert
        Assert.That(a.Selected, Is.False);
        Assert.That(b.Selected, Is.False);
    }
    
    [Test]
    public void GetCardForPlace_PlaceExists_ShouldReturnCard()
    {
        // Arrange
        int place = 2;
        Game game = new Game(); // Instantiate your Game class

        // Act
        Cards result = game.GetCardForPlace(placeWithCard, place);

        // Assert
        Assert.IsNotNull(result);
        Assert.AreEqual(2, result.Id); // Replace 2 with the expected card ID
    }

    [Test]
    public void GetCardForPlace_PlaceNotExists_ShouldReturnNull()
    {
        // Arrange
        int place = 4; // Place that doesn't exist
        Game game = new Game(); // Instantiate your Game class
        
        // Assert
        Assert.Throws<CardNotFoundException>(() => game.GetCardForPlace(placeWithCard, place));
    }
    
    [Test]
    public void PrintBoard_PrintsCorrectlyWithFoundCards()
    {
        // Arrange
        Game game = new Game();
        var cards = new List<Cards>
        {
            new Cards(1, false, true),
            new Cards(2, true, false),
            new Cards(3,  false, false),
            new Cards(4, true, true),
        };
        StringWriter sw = new StringWriter();
        Console.SetOut(sw);

        // Act
        game.PrintBoard(cards);
        string result = sw.ToString().Trim();

        // Assert
        string[] lines = result.Split('\n');
        Assert.AreEqual($"{1}: (1){2}: (2){3}:( ? ){4}: (4)", lines[0]);
        Assert.AreEqual(1, lines.Length);
    }

    [Test]
    public void PrintBoard_PrintsCorrectlyWithUnfoundCards()
    {
        // Arrange
        List<Cards> cards = new List<Cards>
        {
            new Cards(1, false, false),
            new Cards(2, false, false),
            new Cards(3,  false, false),
            new Cards(4, false, false),
            // Add more cards as needed
        };
        Game game = new Game(); // Initialize your Game object

        // Act
        using (StringWriter sw = new StringWriter())
        {
            Console.SetOut(sw);
            game.PrintBoard(cards);
            string printed = sw.ToString().Trim();

            // Assert
            Assert.AreEqual("1:( ? )2:( ? )3:( ? )4:( ? )", printed); // Adjust the expected output accordingly
        }
    }
    
    [Test]
    public void TestShuffleBoard()
    {
        // Arrange
        List<Cards> cards = new List<Cards>
        {
            new Cards(1, false, false),
            new Cards(2, false, false),
            new Cards(3, false, false),
            new Cards(4, false, false),
            // Add more cards as needed
        };
        List<Cards> originalOrder = new List<Cards>(cards); // Make a copy of the original order

        Game game = new Game(); // Initialize your Game object

        // Act
        game.ShuffleBoard(cards);

        // Assert
        Assert.AreNotEqual(originalOrder, cards); // Check if the cards list is shuffled
    }
    
    [Test]
    public void TestMakeCards()
    {
        // Arrange
        int number = 6; // Change to the desired number
        Game game = new Game(); // Initialize your Game object

        // Act
        List<Cards> cards = game.MakeCards(number);

        // Assert
        Assert.IsNotNull(cards);
        Assert.AreEqual(number * 2, cards.Count); // Check if the expected number of cards is created

        // Check if there are pairs of cards with the same ID
        for (int i = 0; i < cards.Count; i += 2)
        {
            Assert.AreEqual(cards[i].Id, cards[i + 1].Id);
        }
    }
    
    [Test]
    public void MakeCardWithImgPathList_InsufficientImages_ThrowsException()
    {
        // Arrange
        Game game = new Game();
        int aantalkaarten = 10; // Assuming there are fewer than 10 images
        List<string> pathList = new List<string> { "image1.jpg", "image2.jpg" }; // Example list with fewer images

        // Act & Assert
        Assert.Throws<ArgumentException>(() => game.MakeCardWithImgPathList(aantalkaarten, pathList));
    }
}
