﻿using Model;

namespace MemoryTesten;

public class CardTests
{
    [Test]
    public void TestCardId()
    {
        // Arrange
        int expectedId = 42;
        Cards card = new Cards(expectedId);

        // Act
        int actualId = card.Id;

        // Assert
        Assert.AreEqual(expectedId, actualId);
    }

    [Test]
    public void TestCardIsFound()
    {
        // Arrange
        Cards card = new Cards();

        // Act
        card.IsFound = true;
        bool isFound = card.IsFound;

        // Assert
        Assert.IsTrue(isFound);
    }

    [Test]
    public void TestCardSelected()
    {
        // Arrange
        Cards card = new Cards();

        // Act
        card.Selected = true;
        bool selected = card.Selected;

        // Assert
        Assert.IsTrue(selected);
    }

    [Test]
    public void TestCardWithParameters()
    {
        // Arrange
        int id = 24;
        bool isFound = true;
        bool selected = false;

        // Act
        Cards card = new Cards(id, isFound, selected);

        // Assert
        Assert.AreEqual(id, card.Id);
        Assert.AreEqual(isFound, card.IsFound);
        Assert.AreEqual(selected, card.Selected);
    }
    
    [Test]
    public void TestCardImgPath()
    {
        // Arrange
        string expectedImgPath = "image.png";
        Cards card = new Cards();
            
        // Act
        card.ImgPath = expectedImgPath;
        string actualImgPath = card.ImgPath;
            
        // Assert
        Assert.AreEqual(expectedImgPath, actualImgPath);
    }
    
    [Test]
    public void TestCardPlaats()
    {
        // Arrange
        int expectedPlaats = 10;
        Cards card = new Cards();
            
        // Act
        card.plaats = expectedPlaats;
        int actualPlaats = card.plaats;
            
        // Assert
        Assert.AreEqual(expectedPlaats, actualPlaats);
    }
    
    [Test]
    public void TestCardPropertyChangedEventIsSelected()
    {
        // Arrange
        Cards card = new Cards();
        bool eventRaised = false;
        card.PropertyChanged += (sender, e) => eventRaised = true;
            
        // Act
        card.Selected = true;
            
        // Assert
        Assert.IsTrue(eventRaised, "PropertyChanged event was not raised when setting Selected.");
    }
    [Test]
    public void TestCardPropertyChangedEventIsFound()
    {
        // Arrange
        Cards card = new Cards();
        bool eventRaised = false;
        card.PropertyChanged += (sender, e) => eventRaised = true;
            
        // Act
        card.IsFound = true;
            
        // Assert
        Assert.IsTrue(eventRaised, "PropertyChanged event was not raised when setting IsFound.");
    } 
    [Test]
    public void TestCardPropertyChangedEventImgPath()
    {
        // Arrange
        Cards card = new Cards();
        bool eventRaised = false;
        card.PropertyChanged += (sender, e) => eventRaised = true;
            
        // Act
        card.ImgPath = "prenk";
            
        // Assert
        Assert.IsTrue(eventRaised, "PropertyChanged event was not raised when setting ImgPath.");
    }
    
    [Test]
    public void TestCardIsFoundEdgeCase()
    {
        // Arrange
        Cards card = new Cards();

        // Act
        card.IsFound = true;
        card.IsFound = false;

        // Assert
        Assert.IsFalse(card.IsFound, "IsFound was not set to false after being set to true.");
    }
    
    [Test]
    public void TestCardImgPathEdgeCase()
    {
        // Arrange
        Cards card = new Cards();

        // Act
        card.ImgPath = "image1.png";
        card.ImgPath = "image2.png";

        // Assert
        Assert.AreEqual("image2.png", card.ImgPath, "ImgPath was not set to the latest value.");
    }
}