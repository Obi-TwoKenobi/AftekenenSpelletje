﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Documents;
using DataAccess;
using Microsoft.Win32;
using Model;

namespace MemoryGameWpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DB db = new DB("Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=Memory;Integrated Security=True;");
        private Game Game = new Game();
        public MainWindow()
        {
            InitializeComponent();
            var query = db.SelectHighscores().OrderByDescending(h => h.Highscore).Take(10);
            dataGrid.ItemsSource = query;
        }
        
        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            string playerName = PlayerNameTextBox.Text;
            if (!string.IsNullOrEmpty(playerName))
            {
                if (int.TryParse(NumberOfCardsTextBox.Text, out int numberOfCards))
                {
                    if (numberOfCards > Game.getFilePaths().Count)
                    {
                        MessageBox.Show("Not enough images to create the game. Please add more images.");
                    }
                    else
                    {
                       GamePage gamePage = new GamePage(playerName, numberOfCards);
                       gamePage.Show();
                       Close(); 
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid number of cards.");
                }
            }
            else
            {
                MessageBox.Show("Please enter a player name.");
            }
        }
        private void UploadImages(object sender, RoutedEventArgs e) {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Pictures|*.png;*.jpg;*.webp;*.jpeg";
            openFileDialog.Multiselect = true;
            openFileDialog.CheckFileExists = true;
            openFileDialog.CheckPathExists = true;

            bool? response = openFileDialog.ShowDialog();

            if(response == true) {
                foreach (String file in openFileDialog.FileNames) {
                    var fullPath = file;
                    string[] partsFileName = fullPath.Split('\\');
                    var image= partsFileName[(partsFileName.Length - 1)];
                    Game.SaveImages(image, fullPath);
                }
            }
        }
    }
}