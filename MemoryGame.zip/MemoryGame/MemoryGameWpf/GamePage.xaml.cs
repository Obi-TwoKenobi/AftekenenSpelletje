﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using DataAccess;
using Model;

namespace MemoryGameWpf;

public partial class GamePage : Window
{
    private Game Game = new Game();
    private Stopwatch Stopwatch;
    public ObservableCollection<Cards> Cards { get; set; }
    public List<Cards> clickedCards = new List<Cards>();
    private DB DataAccess = new DB("Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=Memory;Integrated Security=True;");

    public string PlayerName { get; set; }
    public int NumberOfCards { get; set; }

    public GamePage(string playerName, int numberOfCards)
    {
        InitializeComponent();

        PlayerName = playerName;
        NumberOfCards = numberOfCards;
        
        
        Cards = new ObservableCollection<Cards>();
        List<Cards> cardsList = Game.MakeCardWithImgPathList(NumberOfCards, Game.getFilePaths());
        //List<cards> cardList = new......
        /*for (int i = 1; i < 7; i++)
        {
            Game.MakeCardWithImg(i,Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images", $"card{i}.jpeg"), cardsList );
        }*/
        Game.ShuffleBoard(cardsList);
        foreach (var card in cardsList)
        {
            Cards.Add(card);
        }
        
        itemControl.ItemsSource = Cards;

        Stopwatch = new Stopwatch();
        Stopwatch.Start();

    }
    
    private async void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        Image clickedImage = sender as Image;
        if (clickedImage != null)
        {
            Cards card = clickedImage.DataContext as Cards;
            if (card != null)
            {
                clickedCards.Add(card);
                card.Selected = true;
                if (clickedCards.Count == 2)
                {
                    Game.attempts++;
                    Game.CheckPair(clickedCards[0], clickedCards[1], Game);
                    if (clickedCards[0].IsFound)
                    {
                        clickedCards.Clear();
                         if (Game.Solved)
                         {
                             Stopwatch.Stop();
                             double elapsedSeconds = Stopwatch.Elapsed.TotalSeconds;
                             Highscores playerHighscore = new Highscores();
                             playerHighscore.Highscore = Game.CalculateHighscore(elapsedSeconds, Game.attempts, NumberOfCards);
                             MessageBox.Show(
                                 $"dit is de elapsed seconds{elapsedSeconds}, attempts: {Game.attempts}, dit de numderofcards{NumberOfCards}");
                             playerHighscore.Name = PlayerName;
                             DataAccess.InsertHighscore(playerHighscore);
                             MessageBox.Show($"You win! With this score: {playerHighscore.Highscore}");
                             MainWindow mainWindow = new MainWindow(); 
                             mainWindow.Show(); 
                             Close(); 
                         }
                        return;
                    }
                    await Task.Delay(1000);
                    Game.CardFlipDownside(clickedCards[0], clickedCards[1]);
                    clickedCards.Clear();
                }
            }
        }
    }
}