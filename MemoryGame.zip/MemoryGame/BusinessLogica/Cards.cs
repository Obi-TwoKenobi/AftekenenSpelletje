﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Model;

public class Cards : INotifyPropertyChanged
{
  
    private bool isFound;
    private bool selected;
    private string imgPath;
    public int Id { get; set; }
    public bool IsFound
            {
                get => isFound;
                set
                {
                    if (isFound != value)
                    {
                        isFound = value;
                        OnPropertyChanged();
                    }
                }
            }
    
            public bool Selected
            {
                get => selected;
                set
                {
                    if (selected != value)
                    {
                        selected = value;
                        OnPropertyChanged();
                    }
                }
            }
    
            public string ImgPath
            {
                get => imgPath;
                set
                {
                    if (imgPath != value)
                    {
                        imgPath = value;
                        OnPropertyChanged();
                    }
                }
            }
    public int plaats { get; set; }
    
    public Cards() { }
    public Cards(int id)
    {
        Id = id;
    }
    public Cards(int id, string imgPath)
    {
        Id = id;
        ImgPath = imgPath;
    }
    public Cards(int id , bool isFound, bool selected)
    {
        Id = id;
        IsFound = isFound;
        Selected = selected;
    }
    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}