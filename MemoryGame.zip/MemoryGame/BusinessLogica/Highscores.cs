﻿namespace Model;

public class Highscores
{
    //de variabelen die in de database staan zodat dit opgehaalt kan worden.
    private int _highscore;
    private int _playerID;
    private string _name;
    
    public string Name
    {
        get => _name;
        set => _name = value;
    }

    public int Highscore
    {
        get => _highscore;
        set => _highscore = value;
    }

    public int PlayerId
    {
        get => _playerID;
        set => _playerID = value;
    }
}