﻿namespace Model;

public interface IHighscores
{
    void InsertHighscore(Highscores highscores);
    List<Highscores> SelectHighscores();
}