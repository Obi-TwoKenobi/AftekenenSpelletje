﻿namespace Model;

public class DivideByZeroHighscoreException : Exception
{
    public DivideByZeroHighscoreException() : base("Cannot calculate highscore due to division by zero.") { }
}