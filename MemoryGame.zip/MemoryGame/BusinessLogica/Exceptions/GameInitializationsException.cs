﻿namespace Model;

public class GameInitializationsException : Exception
{
    public GameInitializationsException(string message) : base(message) { }
}