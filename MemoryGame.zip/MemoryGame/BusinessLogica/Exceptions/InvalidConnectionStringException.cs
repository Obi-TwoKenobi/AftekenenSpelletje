﻿namespace Model;

public class InvalidConnectionStringException : Exception
{
    public InvalidConnectionStringException() : base("Invalid database connection string format.") { }
}