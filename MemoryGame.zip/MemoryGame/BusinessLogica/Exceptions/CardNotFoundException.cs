﻿namespace Model;

public class CardNotFoundException : Exception
{
    public int Place { get; }

    public CardNotFoundException(int place) : base($"Card not found for place {place}")
    {
        Place = place;
    }
}