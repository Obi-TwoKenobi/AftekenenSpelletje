﻿namespace Model;

public class InvalidNumberOfCardsException : Exception
{
    public InvalidNumberOfCardsException() : base("Number of cards exceeds the available image paths.") {}
}