﻿using System.Diagnostics;

namespace Model;

public class Game
{
    public int attempts = 0;
    private static double Highscore = 0;
    public int aantalKaarten = 0;
    public List<Cards> Kaarten { get; } = new List<Cards>();
    public List<Cards> CardsList { get; } = new List<Cards>();
    
    //kijkt of de game al klaar is
    private bool _solved;
    //houdt bij hoeveel paren zijn opgelost
    private int _found;

    public bool Solved
    {
        get => _solved;
        set => _solved = value;
    }

    public int Found
    {
        get => _found;
        set => _found = value;
    }
     //methode om de kaarten aan te maken
    public List<Cards> MakeCards(int Number)
    {
        aantalKaarten = Number;
        for (int i = 1; i <= Number; i++)
        {
            Cards cardsA = new Cards(i);
            Cards cardsB = new Cards(i);
            CardsList.Add(cardsA);
            CardsList.Add(cardsB);
        }
        return CardsList;
    }

    //voor handmatige afbeeldingen
     public void MakeCardWithImg(int id, string img, List<Cards> cardsList)
     {
         Cards cardA = new Cards(id, img);
         Cards cardB = new Cards(id, img);
         cardsList.Add(cardA);
         cardsList.Add(cardB);
         aantalKaarten = cardsList.Count / 2;
     }
    public List<Cards> MakeCardWithImgPathList(int aantalkaarten, List<string> pathList)
    {
        if (aantalkaarten <= pathList.Count)
        {
            aantalKaarten = aantalkaarten;
            for (int i = 1; i <= aantalkaarten; i++)
            {
                Cards cardsA = new Cards(i);
                Cards cardsB = new Cards(i);
                        
                cardsA.ImgPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images", pathList[i-1]);
                cardsB.ImgPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images", pathList[i-1]);
                        
                CardsList.Add(cardsA);
                CardsList.Add(cardsB);
            }
            return CardsList;
        }
        else
        {
            throw new ArgumentException("Number of cards exceeds the number of provided image paths.");
        }
    }

    //methode om het speelbord te husselen
    public void ShuffleBoard(List<Cards> cards)
    {
        Random random = new Random();
        int n = cards.Count;
        while (n > 1)
        {
            n--;
            int k = random.Next(n + 1);
            Cards value = cards[k];
            cards[k] = cards[n];
            cards[n] = value;
        }
    }

    // Methode om het speelbord te printen
    public void PrintBoard(List<Cards> cards)
    {
        int col = 0;
        int plaats = 1;

        foreach (var card in cards)
        {
            card.plaats = plaats;
            Kaarten.Add(card);
            //PlaceWithCards.Add(new Tuple<int, Kaarten>(plaats, card));
            if (col == 4)
            {
                Console.WriteLine();
                col = 0;
            }

            if (card.IsFound || card.Selected)
            {
                Console.Write($"{plaats}: ({card.Id})");
            }
            else
            {
                Console.Write($"{plaats}:( ? )");
            }

            col++;
            plaats++;
        }

        Console.WriteLine("");
    }
    
    //geeft card voor de plaats
    public Cards GetCardForPlace(List<Cards> cards, int place)
    {
        var query = cards.Find(t => t.plaats == place);
        if (query != null) return query;
        throw new CardNotFoundException(place);
    }
   
    
    public void CheckPair(Cards cardA, Cards cardB, Game game)
    {
        if (cardA.Id == cardB.Id)
        {
            game.Found++;
            cardA.IsFound = true;
            cardB.IsFound = true;
            if (game.Found == aantalKaarten) game.Solved = true;
        }
        else
        {
            cardA.Selected = true;
            cardB.Selected = true;
        }
    }
    
    //wanneer er geen paar is gevonden draait deze methode de kaarten weer om(console)
    public void CardFlipDownside(Cards a, Cards b)
    {
        if (!a.IsFound || !b.IsFound)
        {
            a.Selected = false;
            b.Selected = false;
        }
    }
    //methode die de highscore van het spel berekent
    public int CalculateHighscore(double sec, int attempts, int NumberOfCards)
    {
        if (sec <= 0 || attempts <= 0)
        {
            return 0; // Avoid division by zero or negative numbers
        }
    
        double highscore = (Math.Pow(NumberOfCards, 2) / (sec * attempts)) * 1000;
    
        if (highscore == double.PositiveInfinity)
        {
            throw new DivideByZeroHighscoreException();
        }
    
        return (int)Math.Round(highscore); // Round to the nearest integer
    }
    public List<string> getFilePaths()
    {
        List<string> filepaths = new List<string>();
        var files = Directory.GetFiles(@"..\..\..\Images", "*.*", SearchOption.AllDirectories);

        string basePath = Path.GetFullPath(@"..\..\..\Images");
        foreach (string file in files)
        {
            if (!file.Equals(@"..\..\..\Images\questionmark.jpeg"))
            {
                string strippedPath = Path.Combine(basePath, Path.GetFileName(file));
                filepaths.Add(strippedPath);
            }
           
        }
        return filepaths;
    }
    
    public void SaveImages(string image, string fullPath)
    {
        string destinationPath = GetDestinationPath(image, @"..\..\..\Images");

        File.Copy(fullPath, destinationPath, true);
    }
    private static String GetDestinationPath(string filename, string foldername)
    {
        String appStartPath = Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName);

        appStartPath = String.Format(appStartPath + "\\{0}\\" + filename, foldername);
        return appStartPath;
    }
}